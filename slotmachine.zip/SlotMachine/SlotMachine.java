public class SlotMachine
{
    ///////////////////////////
    //       constants       //
    ///////////////////////////
    
    public final int CHERRIES = 0;
    public final int APPLE = 1;
    public final int ORANGE = 2;
    public final int LEMON = 3;
    
    ///////////////////////////
    //   instance variables  //
    ///////////////////////////
    
    private int roller1;   // Contains CHERRIES, APPLE, ORANGE, or LEMON 
    private int roller2;   // Contains CHERRIES, APPLE, ORANGE, or LEMON 
    private int roller3;   // Contains CHERRIES, APPLE, ORANGE, or LEMON 
    private int roller4;   // Contains CHERRIES, APPLE, ORANGE, or LEMON 
    private double jackPot; // amount of jackPot
    
    ///////////////////////////
    //        methods        //
    ///////////////////////////
    
    // updates jackPot by adding 25 cents to its total
    public void insertQuarter()
    {
       
    }
    
    // randomly selects a fruit for each of the four rollers
    public void pullLever()
    {

    }
    
    // displays the current amount of the jackPot
    public void displayJackPot()
    {

    }

    // displays the type of fruit contained in each roller
    public void displayRollers()
    {


    }
    
    // Determines if the user has won the jackPot by matching up
    // all four rollers with the same fruit. If the user wins the
    // method displays the message "Winner" and the amount of the
    // jackpot. Otherwise, it displays the 
    // message "Sorry, Please Try Again".
    public void displayResults()
    {       

    }
}